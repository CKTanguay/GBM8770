function [train, test] = load_dataset()
    % Charge les images de l'ensemble d'entrainement et de test dans 2
    % objets struct. Pour chaque �chantillon, il faut cr�er une ligne dans
    % le dataset contenant les attributs ['line', 'data', 'label', 'mask'].
    % On pourra ainsi acc�der � la premi�re image du dataset d'entrainement
    % avec train(1).data.
    % La copie int�grale d'un dataset peut se faire avec la commande: 
    %       trainCopie = train(1,:);
    
    files = dir('DRIVE/data/training/*.png');
    train = struct(['name' 'data' 'label' 'mask'], []);
    
    for i=1:length(files)
        name = files(i).name;
        train(i).name = name;
        %%% TODO I.Q3 Chargez les images data, label et mask:
        % train(i).data = ... ; % Type: double, intensit� comprises entre 0 et 1
        % train(i).label = ... ; % Type: bool�en
        % train(i).mask = ... ;  % Type: bool�en
    end
    
    %%% TODO I.Q3 De la m�me mani�re, chargez les images de test.
    % ...
    % test = ... ;
    % ...

end